//
//  Exercise.swift
//  Projeto_final
//
//  Created by Turma02-8 on 08/04/25.
//

import SwiftUI

struct Exercise: View {
    var body: some View {
        ZStack{
            Color(.navBar).ignoresSafeArea()
        }
    }
}

#Preview {
    Exercise()
}
